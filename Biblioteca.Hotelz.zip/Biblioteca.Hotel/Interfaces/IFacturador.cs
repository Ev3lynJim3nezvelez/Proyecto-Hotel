﻿using Biblioteca.Hotel.Clases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Hotel.Interfaces
{
    public interface IFacturador
    {
        Factura generar_factura(Estancia estancia, bool esExtranjero);
    }
}
