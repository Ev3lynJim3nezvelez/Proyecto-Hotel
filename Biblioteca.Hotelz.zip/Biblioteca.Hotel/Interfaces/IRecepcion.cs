﻿
using Biblioteca.Hotel.Clases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Hotel.Interfaces

{ 
    public interface IRecepcion
    {
        Estancia check_in(Persona persona, Reserva reserva);
        Factura check_out(Estancia estancia);
        void registrar_consumo(Estancia estancia, IServicioConsumible consumo);
    }
}