﻿using Biblioteca.Hotel.Clases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Hotel.Servicios
{
    public class MonitorInventario
    {
        public Clases.Hotel hotel;

        public MonitorInventario(Clases.Hotel hotel)
        {
            if (hotel == null)
                throw new ArgumentNullException(nameof(hotel));

            this.hotel = hotel;
        }
        public void ManejarConsumoProducto(Producto producto)
        {
            
            Console.WriteLine($"[AVISO DE INVENTARIO] Producto consumido: {producto.Obtener_descripcion()}. Se requiere reposición de stock.");
        }
    }
}
