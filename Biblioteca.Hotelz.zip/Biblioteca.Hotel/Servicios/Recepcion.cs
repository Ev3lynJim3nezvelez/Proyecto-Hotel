﻿
using Biblioteca.Hotel.Clases;
using Biblioteca.Hotel.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Hotel.Servicios
{
    public delegate void NotificacionHandler(string mensaje);

    public class Recepcion : IRecepcion
    {
        public event NotificacionHandler OnCheckInExitoso;
        public event NotificacionHandler OnCheckOutExitoso;
        public event NotificacionHandler OnReservaCancelada;

        public event Action<Producto, byte> OnProductoConsumido;

        public List<Estancia> estancias_activas;
        protected IFacturador facturador;

        public Recepcion(IFacturador facturador)
        {
            if (facturador == null)
            {
                throw new ArgumentNullException(nameof(facturador));
            }
            this.facturador = facturador;
            this.estancias_activas = new List<Estancia>();
        }

        
        public Estancia check_in(Persona huesped, Reserva reserva)
        {
            if (huesped == null || reserva == null)
            {
                throw new ArgumentNullException("Huesped o Reserva no pueden ser nulos.");
            }

            
            OnCheckInExitoso?.Invoke($"Check-in exitoso para {huesped.obtener_nombre()} en habitación {reserva.habitacion.obtener_numero()}.");

            
            Estancia nuevaEstancia = new Estancia(huesped, reserva.habitacion);
            estancias_activas.Add(nuevaEstancia);
            return nuevaEstancia;
        }

        public Factura check_out(Estancia estancia)
        {
            if (estancia == null)
            {
                throw new ArgumentNullException(nameof(estancia));
            }
            if (!estancias_activas.Contains(estancia))
            {
                throw new InvalidOperationException("La estancia no se encuentra activa.");
            }

            
            bool esExtranjero = estancia.Huesped_principal.es_extranjero();

            
            Factura factura = facturador.generar_factura(estancia, esExtranjero);

            estancias_activas.Remove(estancia);

            
            OnCheckOutExitoso?.Invoke($"Check-out completado para {estancia.Huesped_principal.obtener_nombre()}. Factura generada.");

            return factura;
        }

        public void registrar_consumo(Estancia estancia, IServicioConsumible consumo)
        {
            if (estancia == null || consumo == null)
            {
                throw new ArgumentNullException("Estancia o Consumo no pueden ser nulos.");
            }

            if (!estancias_activas.Contains(estancia))
            {
                throw new InvalidOperationException("El consumo solo puede registrarse en estancias activas.");
            }

            
            estancia.consumos.Add(consumo);
        }

        public void cancelar_reserva(Reserva reserva)
        {
            if (reserva == null)
            {
                throw new ArgumentNullException(nameof(reserva));
            }

            
            OnReservaCancelada?.Invoke($"Reserva cancelada para {reserva.persona.obtener_nombre()}. La habitación está disponible.");
        }

        public Estancia obtener_estancia_por_huesped(Persona huesped)
        {
            
            return estancias_activas.FirstOrDefault(e => e.Huesped_principal.obtener_nombre() == huesped.obtener_nombre());
        }
    }
}
