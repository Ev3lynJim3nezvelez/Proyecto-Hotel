﻿using Biblioteca.Hotel.Clases;
using Biblioteca.Hotel.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Hotel.Servicios
{
    public class Facturador : IFacturador
    {
        private const double TASA_IVA = 0.19;
        private const double TASA_SEGURO_HOTELERO = 0.025;
        private const double TASA_DESCUENTO = 0.05;

        public Facturador()
        {
        }

        public Factura generar_factura(Estancia estancia, bool esExtranjero)
        {
            if (estancia.Fecha_check_out == DateTime.MinValue)
            {
                estancia.Fecha_check_out = DateTime.Now;
            }

            double totalNoches = estancia.calcular_total_noches();
            ulong precioNocheUlong = estancia.Habitacion_ocupado.Precio_por_noche;

            double costoAlojamiento = (double)precioNocheUlong * totalNoches;

            double totalConsumo = estancia.Consumos.Sum(c => c.Obtener_precio());

            double valorSeguro = costoAlojamiento * TASA_SEGURO_HOTELERO;

            double subtotalBase = costoAlojamiento + totalConsumo + valorSeguro;

            double valorIVA = 0.0;
            double valorDescuento = 0.0;

            if (esExtranjero)
            {
                valorDescuento = subtotalBase * TASA_DESCUENTO;
            }
            else
            {
                valorIVA = subtotalBase * TASA_IVA;
            }

            double totalPagar = subtotalBase + valorIVA - valorDescuento;

            return new Factura(
                estancia,
                totalNoches,
                totalConsumo,
                valorSeguro,
                valorIVA,
                valorDescuento,
                totalPagar
            );
        }
    }
}
