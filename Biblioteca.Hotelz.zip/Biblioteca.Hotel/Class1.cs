﻿namespace Biblioteca.Hotel
{
    public class Class1
    {

    }
}
