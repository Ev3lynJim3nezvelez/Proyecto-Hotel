﻿
using Biblioteca.Hotel.Clases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Hotel.Aspectos
{
    public class ValidadorEntrada
    {
        public void antes_de_guardar(object datos)
        {
            if (datos == null)
                throw new ArgumentNullException(nameof(datos), "Los datos a validar no pueden ser nulos.");

            if (datos is Persona persona)
            {
                if (string.IsNullOrEmpty(persona.obtener_nombre()))
                    throw new ArgumentException("El nombre de la persona es obligatorio.");
            }
            
            else if (datos is Reserva reserva)
            {
                if (reserva.fecha_inicio >= reserva.fecha_fin)
                    throw new ArgumentException("La fecha de Check-out debe ser posterior a la de Check-in.");
            }
           

           
        }
    }
}
