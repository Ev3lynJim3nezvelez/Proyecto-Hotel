﻿
using Biblioteca.Hotel.Clases;
using Biblioteca.Hotel.Interfaces;
using Castle.DynamicProxy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Hotel.Aspectos
{
    public class InterceptorRecepcion : IInterceptor
    {
        private readonly ControlAutenticacion _auth;
        private readonly ValidadorEntrada _validador;

        public InterceptorRecepcion (ControlAutenticacion auth, ValidadorEntrada validador)
        {
            _auth = auth;
            _validador = validador;
        }

        public void Intercept(IInvocation invocation)
        {
            string methodName = invocation.Method.Name;

            
            if (methodName == nameof(IRecepcion.check_out))
            {
               
                if (!_auth.verificar_acceso("empleado", "secreto"))
                {
                    throw new UnauthorizedAccessException($"Acceso denegado. Se requiere autenticación para ejecutar {methodName}.");
                }
            }

            
            if (methodName == nameof(IRecepcion.check_in) || methodName == nameof(IRecepcion.registrar_consumo))
            {
                foreach (var arg in invocation.Arguments)
                {
                    
                    if (arg is Persona || arg is Reserva || arg is IServicioConsumible || arg is Estancia)
                    {
                        _validador.antes_de_guardar(arg);
                    }
                }
            }

           
            invocation.Proceed();
        }
    }
}
