﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Hotel.Aspectos
{
    public class ControlAutenticacion
    {
        public bool verificar_acceso(string usuario, string clave)
        {
            if (string.IsNullOrEmpty(usuario) || string.IsNullOrEmpty(clave))
            {
                return false;
            }

           
            if (usuario == "empleado" && clave == "secreto")
            {
                return true;
            }

            return false;
        }
    }
}
