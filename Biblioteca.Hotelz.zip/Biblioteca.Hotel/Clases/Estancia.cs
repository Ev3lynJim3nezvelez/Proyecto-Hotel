﻿
using Biblioteca.Hotel.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Biblioteca.Hotel.Clases
{
    public class Estancia
    {
        protected DateTime fecha_check_in;
        protected DateTime fecha_check_out;
        protected Persona huesped_principal;
        protected Habitacion habitacion_ocupado;
        public List<IServicioConsumible> consumos;

        public Estancia(Persona huesped, Habitacion habitacion)
        {
            if (huesped == null)
                throw new ArgumentNullException(nameof(huesped));
            if (habitacion == null)
                throw new ArgumentNullException(nameof(habitacion));

            this.fecha_check_in = DateTime.Now;
            this.huesped_principal = huesped;
            this.habitacion_ocupado = habitacion;
            this.consumos = new List<IServicioConsumible>();

            habitacion.Estado = Habitacion.Estados.Ocupada.ToString();
        }

        public DateTime Fecha_check_in { get => fecha_check_in; }
        public DateTime Fecha_check_out
        {
            get => fecha_check_out;
            set => fecha_check_out = value;
        }

        public Persona Huesped_principal { get => huesped_principal; }
        public Habitacion Habitacion_ocupado { get => habitacion_ocupado; }
        public List<IServicioConsumible> Consumos { get => consumos; }


        public void registrar_consumo(IServicioConsumible consumo)
        {
            if (consumo == null)
                throw new ArgumentNullException(nameof(consumo));

            consumos.Add(consumo);
        }

        public double calcular_total_noches()
        {
            if (fecha_check_out == DateTime.MinValue)
            {
                return 1.0;
            }

            TimeSpan duracion = fecha_check_out - fecha_check_in;

            return Math.Ceiling(duracion.TotalDays);
        }
    }
}
