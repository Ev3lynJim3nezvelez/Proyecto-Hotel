﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Hotel.Clases
{
    public class Reserva
    {
        public DateTime fecha_inicio;
        public DateTime fecha_fin;
        public Habitacion habitacion;
        public Persona persona;

        public Reserva(DateTime fecha_inicio, DateTime fecha_fin, Habitacion habitacion, Persona persona)
        {
            if (fecha_inicio >= fecha_fin)
                throw new ArgumentException("La fecha de inicio debe ser anterior a la fecha de fin.");
            if (habitacion == null)
                throw new ArgumentNullException(nameof(habitacion));
            if (persona == null)
                throw new ArgumentNullException(nameof(persona));

            this.fecha_inicio = fecha_inicio;
            this.fecha_fin = fecha_fin;
            this.habitacion = habitacion;
            this.persona = persona;
        }

        public DateTime obtener_fecha_inicio()
        {
            return fecha_inicio;
        }

        public int obtener_duracion_noches()
        {
            TimeSpan duracion = fecha_fin - fecha_inicio;

            
            return (int)duracion.TotalDays;
        }

        public void asignar_habitacion(Habitacion nuevaHabitacion)
        {
            if (nuevaHabitacion == null)
                throw new ArgumentNullException(nameof(nuevaHabitacion));

            this.habitacion = nuevaHabitacion;
        }
    }
}
