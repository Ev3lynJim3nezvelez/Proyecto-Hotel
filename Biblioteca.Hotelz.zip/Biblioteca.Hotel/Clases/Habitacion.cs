﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Hotel.Clases
{
    public abstract class Habitacion
    {
        public enum Estados { Disponible, Ocupada, Mantenimiento };

        protected uint numero;
        protected ulong precio_por_noche;
        protected string estado;
        protected byte piso;

        private readonly ulong precio_minimo = 200000;
        private readonly byte piso_minimo = 2;
        private readonly uint numero_minimo = 200; 
        private readonly List<string> estados_validos = new List<string> { "Disponible", "Ocupada", "Mantenimiento" };

        
        public Habitacion(uint numero, ulong precio_por_noche, byte piso)
        {
            Numero = numero; 
            Piso = piso;
            Estado = "Disponible";
        }

        public uint Numero
        {
            get => numero;
            set
            {
               
                if (value < numero_minimo)
                    throw new Exception($"El número de habitación debe ser mayor o igual a {numero_minimo}");
                else
                    numero = value;
            }
        }

        public ulong Precio_por_noche
        {
            get => precio_por_noche;
            set
            {
                if (value < precio_minimo)
                    throw new Exception($"El precio por noche debe ser mayor o igual a {precio_minimo}");
                else
                    precio_por_noche = value;
            }
        }

        public byte Piso
        {
            get => piso;
            set
            {
                if (value < piso_minimo)
                    throw new Exception($"El piso no puede ser menor a {piso_minimo}");
                else
                    piso = value;
            }
        }

        public string Estado
        {
            get => estado;
            set
            {
                if (!estados_validos.Contains(value))
                    throw new Exception($"El estado '{value}' no es un estado válido. Use: Disponible, Ocupada, o Mantenimiento.");
                else
                    estado = value;
            }
        }
        public uint obtener_numero() 
        {
            return numero;
        }
        public abstract string Obtener_descripcion_servicio();

        public override string ToString()
        {
            return $"Habitación No. {numero} (Piso {piso}) - Precio: {precio_por_noche:N0} - Estado: {estado}";
        }
    }
}
