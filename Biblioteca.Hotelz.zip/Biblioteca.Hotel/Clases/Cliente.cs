﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Hotel.Clases
{
    public class Cliente : Persona
    {
        protected string codigo_fidelidad;
        protected double dscto_especial;

        public Cliente(string nombre, Tipos_id tipo_id, ulong num_id, ulong telefono, string codigo_fidelidad)
            : base(nombre, tipo_id, num_id, telefono)
        {
            if (string.IsNullOrEmpty(codigo_fidelidad))
                throw new ArgumentNullException(nameof(codigo_fidelidad));

            this.codigo_fidelidad = codigo_fidelidad;

            this.dscto_especial = 0.10; 
        }

        public double obtener_descuento()
        {
            return dscto_especial;
        }

        public void aplicar_descuento(double descuento)
        {
            if (descuento < 0 || descuento > 1)
                throw new ArgumentOutOfRangeException(nameof(descuento), "El descuento debe estar entre 0 y 1 (0% a 100%).");

            this.dscto_especial = descuento;
        }
    }
}
