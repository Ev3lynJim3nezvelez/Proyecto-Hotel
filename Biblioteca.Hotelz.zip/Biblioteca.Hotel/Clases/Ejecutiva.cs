﻿using Biblioteca.Hotel.Clases;
using System;
using System.Collections.Generic;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Ejecutiva : Habitacion
{
    private const ulong PRECIO_BASE = 350000;
    private const byte PISO_ASIGNADO = 5;

    private List<Producto> _inventarioMinibar;
    private Producto _kitAseo;

    public Ejecutiva(uint numero) : base(numero, PRECIO_BASE, PISO_ASIGNADO)
    {
        _kitAseo = new Producto("Kit de Aseo Personal", 3000.00);

        _inventarioMinibar = CargadorDatos.CargarMinibarDesdeArchivo("Ejecutiva");
    }

    public List<Producto> InventarioMinibar
    {
        get => _inventarioMinibar;
    }

    public Producto KitAseoPersonal
    {
        get => _kitAseo;
    }

    public void recargar_minibar()
    {

    }

    public override string Obtener_descripcion_servicio()
    {
        return "Habitación Ejecutiva con amplio espacio, minibar y kit de aseo personal de cortesía.";
    }
}