﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Hotel.Clases
{
    public class Factura
    {
        protected Estancia estancia;
        protected DateTime fecha_emision;
        protected double total_noches;
        protected double total_consumo;
        protected double valor_seguro;
        protected double valor_IVA;
        protected double valor_descuento;
        protected double total_pagar;

        public Factura(Estancia estancia, double total_noches, double total_consumo, double valor_seguro, double valor_IVA, double valor_descuento, double total_pagar)
        {
            if (estancia == null)
                throw new ArgumentNullException(nameof(estancia));

            this.estancia = estancia;
            this.fecha_emision = DateTime.Now;
            this.total_noches = total_noches;
            this.total_consumo = total_consumo;
            this.valor_seguro = valor_seguro;
            this.valor_IVA = valor_IVA;
            this.valor_descuento = valor_descuento;
            this.total_pagar = total_pagar;
        }

        public Estancia Estancia { get => estancia; }
        public DateTime Fecha_emision { get => fecha_emision; }
        public double Total_noches { get => total_noches; }
        public double Total_consumo { get => total_consumo; }
        public double Valor_seguro { get => valor_seguro; }
        public double Valor_IVA { get => valor_IVA; }
        public double Valor_descuento { get => valor_descuento; }
        public double Total_pagar { get => total_pagar; }

        public string imprimir_detalle()
        {
            
            return $"--- Detalle de Factura ---\n" +
                   $"Fecha Emisión: {fecha_emision.ToShortDateString()}\n" +
                   $"Habitación: {estancia.Habitacion_ocupado.Numero}\n" +
                   $"Huésped: {estancia.Huesped_principal.obtener_nombre}\n" +
                   $"Noches de Alojamiento: {total_noches}\n" +
                   $"Subtotal Consumos: {total_consumo:N0}\n" +
                   $"Valor Seguro Hotelero (2.5%): {valor_seguro:N0}\n" +
                   $"Valor IVA (19%): {valor_IVA:N0}\n" +
                   $"Descuento Aplicado: {valor_descuento:N0}\n" +
                   $"--------------------------\n" +
                   $"TOTAL A PAGAR: {total_pagar:N0}";
        }

        public double obtener_total()
        {
            return total_pagar;
        }
    }
}
