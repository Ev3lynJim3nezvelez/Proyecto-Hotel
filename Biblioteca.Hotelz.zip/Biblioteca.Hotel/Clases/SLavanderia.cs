﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Biblioteca.Hotel.Interfaces;

namespace Biblioteca.Hotel.Clases
{
    public class SLavanderia : Servicio
    {
        private const ulong COSTO_LAVADO_POR_PRENDA = 12000;
        private const ulong COSTO_PLANCHADO_POR_PRENDA = 9000;

        public SLavanderia() : base(0, "Servicio de Lavandería (Lavado $12k, Planchado $9k por prenda).")
        {
        }

        public override double Obtener_precio()
        {
            return 0.0;
        }

        public double CalcularCargo(uint numPrendasLavado, uint numPrendasPlanchado)
        {
            ulong cargoTotal = 0;

            cargoTotal += numPrendasLavado * COSTO_LAVADO_POR_PRENDA;
            cargoTotal += numPrendasPlanchado * COSTO_PLANCHADO_POR_PRENDA;

            return (double)cargoTotal;
        }
    }
}
