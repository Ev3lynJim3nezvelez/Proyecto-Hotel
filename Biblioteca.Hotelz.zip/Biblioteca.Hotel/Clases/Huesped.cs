﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Hotel.Clases
{
    public class Huesped : Persona
    {
        public Huesped(string nombre, Tipos_id tipo_id, ulong num_id, ulong telefono)
            : base(nombre, tipo_id, num_id, telefono)
        {
            
        }
    }
}
