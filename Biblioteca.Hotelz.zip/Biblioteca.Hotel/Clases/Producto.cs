﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Biblioteca.Hotel.Interfaces;
namespace Biblioteca.Hotel.Clases
{
    public class Producto: IServicioConsumible
    {
        protected string nombre;
        protected double precio;

        private readonly double precio_minimo = 100;

        public Producto(string nombre, double precio)
        {
            Nombre = nombre;
            Precio = precio;
        }

        public string Nombre
        {
            get => nombre;
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("El nombre del producto no puede ser vacío.");
                nombre = value;
            }
        }

        public double Precio
        {
            get => precio;
            set
            {
                if (value < precio_minimo)
                    throw new Exception($"El precio base debe ser mayor o igual a {precio_minimo}.");
                precio = value;
            }
        }

        public double Obtener_precio()
        {
            return (double)precio;
        }

        public string Obtener_descripcion()
        {
            return $"{nombre} - Precio: {precio:N0}";
        }
    }
}
