﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Biblioteca.Hotel.Interfaces;

namespace Biblioteca.Hotel.Clases
{
    public class SHabitacion : IServicioConsumible
    {
        private const ulong RECARGA_SERVICIO_HABITACION = 5000;

        protected IServicioConsumible servicio_decorado;

        public SHabitacion(IServicioConsumible servicio)
        {
            if (servicio == null)
                throw new ArgumentNullException(nameof(servicio), "Se requiere un servicio base para aplicar el recargo.");

            this.servicio_decorado = servicio;
        }

        public double Obtener_precio()
        {
            double precioBase = servicio_decorado.Obtener_precio();
            double recargo = (double)RECARGA_SERVICIO_HABITACION;

            return precioBase + recargo;
        }

        public string Obtener_descripcion()
        {
            return $"{servicio_decorado.Obtener_descripcion()} (INCLUYE Recargo Servicio Habitación: {RECARGA_SERVICIO_HABITACION:N0})";
        }
    }
}
