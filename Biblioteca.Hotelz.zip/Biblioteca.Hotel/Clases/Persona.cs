﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Biblioteca.Hotel.Clases
{
    public class Persona
    {
        public string nombre;
        public int tipo_id;
        public ulong num_id;
        public ulong telefono;

        public enum Tipos_id { Cedula, Pasaporte, TarjetaIdentidad };

        public Persona(string nombre, Tipos_id tipo_id, ulong num_id, ulong telefono)
        {
            if (string.IsNullOrEmpty(nombre))
                throw new ArgumentNullException(nameof(nombre));
            if (num_id == 0)
                throw new ArgumentException("El número de identificación no puede ser cero.", nameof(num_id));

            this.nombre = nombre;
            this.tipo_id = (int)tipo_id;
            this.num_id = num_id;
            this.telefono = telefono;
        }

        public string obtener_nombre()
        {
            return nombre;
        }

        public bool es_extranjero()
        {
        
            return tipo_id != (int)Tipos_id.Cedula;
        }
    }
}
