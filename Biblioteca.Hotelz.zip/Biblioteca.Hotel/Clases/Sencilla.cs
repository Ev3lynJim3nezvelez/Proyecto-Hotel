﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Hotel.Clases
{
    public class Sencilla : Habitacion
    {
        private const ulong PRECIO_BASE = 200000;
        private const byte PISO_MAXIMO = 4;

      
        public Sencilla(uint numero, byte piso) : base(numero, PRECIO_BASE, piso)
        {
            if (piso > PISO_MAXIMO)
                throw new Exception("Una Habitación Sencilla solo puede estar en los pisos 2, 3, o 4.");
        }
        public override string Obtener_descripcion_servicio()
        {
            return "Habitación sencilla con capacidad para dos personas. No incluye minibar.";
        }
    }
}
