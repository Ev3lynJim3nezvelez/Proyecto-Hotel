﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Biblioteca.Hotel.Interfaces;

namespace Biblioteca.Hotel.Clases
{
    public abstract class Servicio : IServicioConsumible
    {
        protected ulong precio_base;
        protected string descripcion;

        public Servicio(ulong precio_base, string descripcion)
        {
            this.precio_base = precio_base;
            this.descripcion = descripcion;
        }

        public abstract double Obtener_precio();

        public string Obtener_descripcion()
        {
            return descripcion;
        }
    }
}
