﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Biblioteca.Hotel.Interfaces;

namespace Biblioteca.Hotel.Clases
{
    public class SRestaurante : Servicio
    {
        private const ulong PRECIO_DESAYUNO = 15000;
        private const ulong PRECIO_ALMUERZO = 25000;
        private const ulong PRECIO_CENA = 20000;

        public enum TipoOrden { Desayuno, Almuerzo, Cena };

        public SRestaurante() : base(0, "Servicio de Restaurante (Comidas básicas).")
        {
        }

        public override double Obtener_precio()
        {
            return 0.0;
        }

        public double CalcularCargo(TipoOrden tipo)
        {
            ulong costoBase = 0;

            switch (tipo)
            {
                case TipoOrden.Desayuno: costoBase = PRECIO_DESAYUNO; break;
                case TipoOrden.Almuerzo: costoBase = PRECIO_ALMUERZO; break;
                case TipoOrden.Cena: costoBase = PRECIO_CENA; break;
                default: throw new ArgumentException("Tipo de orden no válido.");
            }

            return (double)costoBase;
        }
    }
}
