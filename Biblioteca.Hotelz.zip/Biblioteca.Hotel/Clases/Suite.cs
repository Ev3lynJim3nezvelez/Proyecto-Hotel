﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Hotel.Clases
{
    public class Suite : Habitacion
    {
        private const ulong PRECIO_BASE = 500000;
        private const byte PISO_ASIGNADO = 6;

        private List<Producto> _inventarioMinibar;
        private Producto _kitAseo;
        private Producto _batas;

        public Suite(uint numero) : base(numero, PRECIO_BASE, PISO_ASIGNADO)
        {
            _kitAseo = new Producto("Kit de Aseo Personal", 3); 
            _batas = new Producto("Batas de Baño", 2); 

            _inventarioMinibar = new List<Producto>
            {
                new Producto("Vino", 1),   
                new Producto("Licor", 4),  
                new Producto("Gaseosa", 4) 
            };
        }

        public List<Producto> InventarioMinibar { get => _inventarioMinibar; }
        public Producto KitAseoPersonal { get => _kitAseo; }
        public Producto BatasDeBaño { get => _batas; }

        public void recargar_minibar()
        {
           
        }


        public override string Obtener_descripcion_servicio()
        {
            return "Suite de lujo con minibar especial (vino, licor, gaseosa), 3 kits de aseo y 2 batas de baño.";
        }
    }
}
