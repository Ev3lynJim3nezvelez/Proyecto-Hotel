﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Hotel.Clases
{
    public class ItemStock
    {
        protected string nombre;
        protected double precio;
        protected int cantidad_base;

        public ItemStock(string nombre, double precio, int cantidad_base)
        {
            if (string.IsNullOrEmpty(nombre))
                throw new ArgumentNullException(nameof(nombre));
            if (precio <= 0)
                throw new ArgumentException("El precio debe ser positivo.", nameof(precio));
            if (cantidad_base <= 0)
                throw new ArgumentException("La cantidad base debe ser mayor a cero.", nameof(cantidad_base));

            this.nombre = nombre;
            this.precio = precio;
            this.cantidad_base = cantidad_base;
        }

        public string obtener_nombre()
        {
            return nombre;
        }

        public double obtener_precio()
        {
            return precio;
        }

        public int obtener_cantidad_base()
        {
            return cantidad_base;
        }
    }
}
