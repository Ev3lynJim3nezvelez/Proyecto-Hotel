﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Biblioteca.Hotel.Eventos;

namespace Biblioteca.Hotel.Clases
{
    public class Minibar
    {
        public event ConsumoProductoEventHandler OnProductoConsumido;
        protected List<Producto> productos;
        protected ItemStock stock;
        protected List<Producto> productos_consumidos;

        public Minibar(ItemStock stock)
        {
            if (stock == null)
                throw new ArgumentNullException(nameof(stock));

            this.stock = stock;
            this.productos = new List<Producto>();
            this.productos_consumidos = new List<Producto>();

            this.llenar();
        }

        public void consumir_producto(Producto producto)
        {
            if (producto == null)
                throw new ArgumentNullException(nameof(producto));

            if (!productos.Remove(producto))
            {
                throw new InvalidOperationException("El producto especificado no se encuentra en el minibar.");
            }

            productos_consumidos.Add(producto);
            OnProductoConsumido?.Invoke(producto);
        }

        public void llenar()
        {
            productos.Clear();

            for (int i = 0; i < stock.obtener_cantidad_base(); i++)
            {
                Producto nuevoProducto = new Producto(stock.obtener_nombre(), stock.obtener_precio());
                productos.Add(nuevoProducto);
            }
        }

        public List<Producto> obtener_productos_consumidos()
        {
            return productos_consumidos;
        }
    }
}
