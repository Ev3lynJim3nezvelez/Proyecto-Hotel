﻿
using Biblioteca.Hotel.Servicios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Biblioteca.Hotel.Servicios;
using Biblioteca.Hotel.Interfaces;
using Biblioteca.Hotel.Clases;
using Castle.DynamicProxy;
using Biblioteca.Hotel.Aspectos;
using Biblioteca.Hotel.Eventos;

namespace Biblioteca.Hotel.Clases
{
    public class Hotel
    {
        protected List<Habitacion> habitaciones;
        protected List<Persona> personas;
        protected OficinaReservas oficinaReservas;
        public IRecepcion recepcion;
        protected IFacturador facturador;
        public MonitorInventario monitorInventario;
        protected ControlAutenticacion authService;
        protected ValidadorEntrada validadorService;

        private static readonly ProxyGenerator ProxyGenerator = new ProxyGenerator();

        public Hotel()
        {
            this.habitaciones = new List<Habitacion>();
            this.personas = new List<Persona>();
            this.facturador = new Facturador();

            this.authService = new ControlAutenticacion();
            this.validadorService = new ValidadorEntrada();
            this.monitorInventario = new MonitorInventario(this);
            Recepcion recepcionReal = new Recepcion(this.facturador);
            InterceptorRecepcion interceptor = new InterceptorRecepcion(this.authService, this.validadorService);
            this.recepcion = ProxyGenerator.CreateInterfaceProxyWithTarget<IRecepcion>(
                recepcionReal,
                interceptor );
            this.oficinaReservas = new OficinaReservas(this);
        }
        public IRecepcion Recepcion { get => recepcion; }
        public List<Habitacion> Habitaciones { get => habitaciones; }
        public List<Persona> Personas { get => personas; }
        public OficinaReservas Oficina_reservas { get => oficinaReservas; }

        public void iniciar_sistema()
        {

        }

        public Habitacion BuscarHabitacionDisponible(string tipo_habitacion, DateTime fecha_inicio, DateTime fecha_fin)
        {
            Habitacion habitacionEncontrada = habitaciones.Find(h =>
                h.GetType().Name == tipo_habitacion && h.Estado == Habitacion.Estados.Disponible.ToString());

            return habitacionEncontrada;
        }
    }
}