﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Hotel.Clases
{
    public static class CargadorDatos
    {
        public static List<Producto> CargarMinibarDesdeArchivo(string tipoHabitacion)
        {
            Console.WriteLine($"[INFO]: Cargando inventario del minibar para '{tipoHabitacion}' desde fuente externa...");

            return new List<Producto>
            {
                new Producto("Cerveza Importada", 4000.00),
                new Producto("Gaseosa dietética", 3100.00),
                new Producto("Snack Premium", 3500.00)
            };
        }
    }
}
