﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca.Hotel.Clases

{
    public class OficinaReservas
    {
        protected List<Reserva> reservas;
        protected Hotel hotel;

        public OficinaReservas(Hotel hotel)
        {
            if (hotel == null)
                throw new ArgumentNullException(nameof(hotel), "La Oficina de Reservas debe estar asociada a un Hotel.");

            this.hotel = hotel;
            this.reservas = new List<Reserva>();
        }

        public Reserva crear_reserva(Persona persona, DateTime fecha_inicio, DateTime fecha_fin, string tipo_habitacion)
        {
            if (fecha_inicio >= fecha_fin)
                throw new ArgumentException("La fecha de inicio debe ser anterior a la fecha de fin.");
            if (fecha_inicio < DateTime.Today)
                throw new ArgumentException("No se pueden crear reservas en el pasado.");

            Habitacion habitacion_disponible = hotel.BuscarHabitacionDisponible(tipo_habitacion, fecha_inicio, fecha_fin);

            if (habitacion_disponible == null)
            {
                throw new InvalidOperationException($"No hay habitaciones de tipo '{tipo_habitacion}' disponibles para esas fechas.");
            }

            Reserva nuevaReserva = new Reserva(fecha_inicio, fecha_fin, habitacion_disponible,persona);

            reservas.Add(nuevaReserva);

            return nuevaReserva;
        }

        public void Cancelar_reserva(Reserva reserva)
        {
            if (reserva == null)
                throw new ArgumentNullException(nameof(reserva));

            if (!reservas.Contains(reserva))
            {
                throw new InvalidOperationException("La reserva especificada no fue encontrada.");
            }

            reservas.Remove(reserva);
        }
    }
}
